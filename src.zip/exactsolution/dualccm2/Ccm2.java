package exactsolution.dualccm2;

public class Ccm2 {
}
