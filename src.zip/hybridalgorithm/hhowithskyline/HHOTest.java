package hybridalgorithm.hhowithskyline;


/**
 * @author xzbz
 * @create 2023-09-07 10:13
 */
// public class HHOTest {
//     public static void main(String[] args) {
//         double x = 2.5; // 要计算Gamma函数的值
//         double gammaValue = Gamma.gamma(x);
//
//         System.out.println("Gamma(" + x + ") = " + gammaValue);
//     }
// }
