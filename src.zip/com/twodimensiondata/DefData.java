package com.twodimensiondata;

/**
 * @author xzbz
 * @create 2023-10-20 15:00
 */
public class DefData {
    public double[] defInfo;
    public int defIndex;

    public boolean isUsed;

    public DefData(double[] defInfo, int defIndex) {
        this.defInfo = defInfo;
        this.defIndex = defIndex;
    }
}
